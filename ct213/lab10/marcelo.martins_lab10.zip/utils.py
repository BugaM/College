# Types of cells
UNDEFINED = -1
EMPTY = 0
GOAL = 1
OBSTACLE = 2

# Types of actions
STOP = 0
UP = 1
RIGHT = 2
DOWN = 3
LEFT = 4
NUM_ACTIONS = 5

